typedef struct
{
	int jour;
	int mois;
	int annee;
}date;
typedef struct
{
	char entree[50];
	char plat_principale[50];
	char dessert[50];
}plat;
typedef struct
{
	date  d;
	char temps[50];
	plat menu;

}menu;
void afficher(GtkWidget *treeview1, char ch[]);
void ajout_menu(menu m);
void supprimer_menu(int jour,int mois,int annee,char temps[]);
void rechercher_menu1(char plat[]);
void rechercher_menu2(int jo,int mo,int an,char temp1[]);
void modifier_menu(menu me);
void meilleur_menu(GtkWidget *treeview1);



