#include <gtk/gtk.h>


void
on_treeview1_wejden_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ajout_wejden_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_wejden_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_mod_wejdenn_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supp_wejdenn_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_meill_wejdenn_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_rech_wejdenn_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_wejdennn_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button7_wejdenn_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_wejdenn_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_wejdennn_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_wejdenn_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_wejdennn_clicked            (GtkButton       *button,
                                        gpointer         user_data);
