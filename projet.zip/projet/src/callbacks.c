#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdbool.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "fct.h"
int x=0;
int t[2]={0,0};
char ch[100];
menu me;



void
on_treeview1_wejden_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
 gint *j;
        gint *m;
        gint *a;
        gchar  *temps;
	gchar  *entree;
        gchar *plat;
	gchar *dessert;
      
       GtkTreeIter iter;
	
	

	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path))
	{ 
	  gtk_tree_model_get (GTK_LIST_STORE(model), &iter,  0, &j,1,&m,2,&a,3,&temps,4,&entree,5,&plat,6,&dessert,-1);
	  me.d.jour=j;
	  me.d.mois=m;
	  me.d.annee=a;
	  strcpy(me.temps,temps);
	  strcpy(me.menu.entree,entree);
	  strcpy(me.menu.plat_principale,plat);
	  strcpy(me.menu.dessert,dessert);


	}
}


void
on_button_ajout_wejden_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter;
ajouter = create_ajout();
  gtk_widget_show (ajouter);

}


void
on_button11_wejden_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *affiche;
affiche=lookup_widget(button,"affichage");
strcpy(ch,"menu.txt");
afficher(lookup_widget(affiche,"treeview1_wejden"),ch);


}


void
on_button_mod_wejdenn_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modif;
char chj[10],chm[10],cha[10];
modif = create_modifier();
  gtk_widget_show (modif);

GtkWidget* msgjour=lookup_widget(modif,"label21");
sprintf(chj,"%d",me.d.jour);
gtk_label_set_text(GTK_LABEL(msgjour),chj);
gtk_widget_show(msgjour);

GtkWidget* msgmois=lookup_widget(modif,"label23");
sprintf(chm,"%d",me.d.mois);
gtk_label_set_text(GTK_LABEL(msgmois),chm);
gtk_widget_show(msgmois);


GtkWidget* msgannee=lookup_widget(modif,"label25_wejden");
sprintf(cha,"%d",me.d.annee);
gtk_label_set_text(GTK_LABEL(msgannee),cha);
gtk_widget_show(msgannee);

gtk_entry_set_text(GTK_ENTRY(lookup_widget(modif,"entry4_wejdenn")),me.menu.entree);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(modif,"entry5_wejdennn")),me.menu.plat_principale);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(modif,"entry6_wejdennn")),me.menu.dessert);



}


void
on_button_supp_wejdenn_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
supprimer_menu(me.d.jour,me.d.mois,me.d.annee,me.temps);
GtkWidget *confirmesupprimer;
confirmesupprimer=lookup_widget(button,"affichage");
strcpy(ch,"menu.txt");
afficher(lookup_widget(button,"treeview1_wejden"),ch);

}


void
on_button_meill_wejdenn_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *affiche;
affiche=lookup_widget(button,"affichage");
meilleur_menu(lookup_widget(affiche,"treeview1_wejden"));
}


void
on_checkbutton1_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{t[0]=1;}
}


void
on_checkbutton2_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{t[1]=1;}

}


void
on_button_rech_wejdenn_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
if (t[0]==1)
{
GtkWidget *entry_plat;
char r[100];
entry_plat=lookup_widget(button,"entry7_wejdenn");
strcpy(r,gtk_entry_get_text(GTK_ENTRY(entry_plat) ) );
rechercher_menu1(r);
GtkWidget *affiche;
affiche=lookup_widget(button,"affichage");
strcpy(ch,"rech1.txt");
afficher(lookup_widget(affiche,"treeview1_wejden"),ch);
}
if (t[1]==1)
{
GtkWidget *Jour1,*Mois1,*Annee1,*Combobox1;
int jo,mo,an;
char temps1[100];
Jour1=lookup_widget(button,"entry_jour1_wejdenn");
Mois1=lookup_widget(button,"entry_mois1_wejdenn");
Annee1=lookup_widget(button,"entry_annee1_wejdenn");
Combobox1=lookup_widget(button,"combobox1");
jo= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour1));
mo= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois1));
an= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee1));
strcpy(temps1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));
rechercher_menu2(jo,mo,an,temps1);
GtkWidget *affiche;
affiche=lookup_widget(button,"affichage");
strcpy(ch,"rech2.txt");
afficher(lookup_widget(affiche,"treeview1_wejden"),ch);



}

}


void
on_radiobutton2_wejdennn_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;}

}


void
on_radiobutton1_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=2;}

}


void
on_radiobutton3_wejdenn_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=3;}
}


void
on_button7_wejdenn_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
menu m;
GtkWidget *affichage;
GtkWidget *entry_entree, *entry_plat, *entry_dessert, *entry_temps ,*Jour,*Mois,*Annee;
GtkWidget *Ajout;
Ajout=lookup_widget(button,"ajout");

entry_entree=lookup_widget(button,"entry_entree_wejdenn");
entry_plat=lookup_widget(button,"entry_plat_wejdenn");
entry_dessert=lookup_widget(button,"entry_dinner_wejdenn");
Jour=lookup_widget(button,"entry_jour_wejdennn");
Mois=lookup_widget(button,"entry_mois_wejdennn");
Annee=lookup_widget(button,"entry_annee_wejdennn");


 strcpy(m.menu.entree,gtk_entry_get_text(GTK_ENTRY(entry_entree) ) );
 strcpy(m.menu.plat_principale,gtk_entry_get_text(GTK_ENTRY(entry_plat) ) );
 strcpy(m.menu.dessert,gtk_entry_get_text(GTK_ENTRY(entry_dessert) ) );
 if (x==1){
strcpy(m.temps,"petit_dejeuner");}
else 
if (x==2){
strcpy(m.temps,"dejeuner");}
else
{strcpy(m.temps,"dinner");}

 m.d.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
 m.d.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
 m.d.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));



ajout_menu(m);
gtk_widget_destroy(Ajout);
}


void
on_button6_wejdenn_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Ajout;
Ajout=lookup_widget(button,"ajout");
gtk_widget_destroy(Ajout);


}


void
on_button8_wejdennn_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *mod;
mod=lookup_widget(button,"modifier");
gtk_widget_destroy(mod);

}


void
on_button9_wejdenn_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry_entree, *entry_plat, *entry_dessert,*mod;
mod=lookup_widget(button,"modifier");
entry_entree=lookup_widget(button,"entry4_wejdenn");
entry_plat=lookup_widget(button,"entry5_wejdennn");
entry_dessert=lookup_widget(button,"entry6_wejdennn");
 strcpy(me.menu.entree,gtk_entry_get_text(GTK_ENTRY(entry_entree) ) );
 strcpy(me.menu.plat_principale,gtk_entry_get_text(GTK_ENTRY(entry_plat) ) );
 strcpy(me.menu.dessert,gtk_entry_get_text(GTK_ENTRY(entry_dessert) ) );
modifier_menu(me);
gtk_widget_destroy(mod);
}



