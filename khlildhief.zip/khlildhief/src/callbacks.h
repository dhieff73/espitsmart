#include <gtk/gtk.h>




void
on_button37khlil_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1khlil_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

gboolean
on_treeview1khlil_select_cursor_row    (GtkTreeView     *treeview,
                                        gboolean         start_editing,
                                        gpointer         user_data);

void
on_button1khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button9khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3khlil_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button36khlil_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6khlil_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button5khlil_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button8kkhlil_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12khlil_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button10khlil_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton6khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton5khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button11khlil_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton1khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button13khlil_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button14khlil_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button37_retourkhlil_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton3khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button36khlil_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8kkhlil_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton4khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button37_retourkhlil_clicked        (GtkButton       *button,
                                        gpointer         user_data);
