#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "produit.h"

int x=0;
int k=0;
int y=0;
int z=0 ;
int e=0;
int q=0;
char iden[20];
produit cli ;
int w ;
int m;
char idd[20];


void
on_treeview1khlil_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* mois ;
gchar* annee;
gchar* quantite;
gchar* nom;
gchar* type;
produit c;

char fichier[]={"produit.txt"};

GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&mois,1,&annee,2,&quantite,3,&nom,4,&type,-1);

strcpy(c.id,nom);
strcpy(c.mois,mois);
strcpy(c.annee,annee);
strcpy(c.quantite,quantite);
strcpy(c.type,type);

strcpy(idd,c.id);

affichage(fichier,treeview);
}

}


gboolean
on_treeview1khlil_select_cursor_row         (GtkTreeView     *treeview,
                                        gboolean         start_editing,
                                        gpointer         user_data)
{

  return FALSE;
}

//boutton rechercher produit
void
on_button4khlil_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_ajouter,*input2,*treeview1;

char fichier[]={"test.txt"};
char fichierr[]={"produit.txt"};
char x [20];
produit c ;
//partie recherche identite
window_ajouter=lookup_widget(objet,"window1");
input2=lookup_widget(objet,"entry1khlil");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(input2)));
c=recherche(fichierr,x);
//partie fichier test
FILE *f;
f = fopen(fichier,"a+");
if ( f != NULL )
fprintf(f,"%s %s %s %s %s \n",c.mois,c.annee,c.quantite,c.id,c.type) ;
fclose (f) ;

//partie affichage
GtkWidget *input,*input1;
input=lookup_widget(objet,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet,"window1");
gtk_widget_destroy(input1);
gtk_widget_show(input);
treeview1=lookup_widget(input,"treeview1");
affichage(fichier,treeview1);
remove(fichier);
}

//boutton ajouter menu produit
void
on_button1khlil_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
char text1[20];
char text2[40];
strcpy(text1,"nourriture");
strcpy(text2,"nettoyage");
GtkWidget *input,*input1;
GtkWidget *combobox1khlil;
input=create_window2();
gtk_widget_show(input);
combobox1khlil=lookup_widget(input,"combobox1khlil");
gtk_combo_box_append_text(GTK_COMBO_BOX(combobox1khlil),text1);
gtk_combo_box_append_text(GTK_COMBO_BOX(combobox1khlil),text2);

input1=lookup_widget(objet,"window1");
gtk_widget_destroy(input1);
}

//boutton afficher produit
void
on_button9khlil_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
char fichier[]={"produit.txt"};
GtkWidget *input,*input1,*treeview1khlil;
input=lookup_widget(objet,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet,"window1");
gtk_widget_destroy(input1);
gtk_widget_show(input);
treeview1khlil=lookup_widget(input,"treeview1khlil");
affichage(fichier,treeview1khlil);
}

//boutton modifier menu produit
void
on_button2khlil_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1,*window4,*input2,*treeview1,*output,*output1,*output2,*output3,*output4,*output5,*output6;
GtkWidget *input,*input1;

char fichierr[]={"produit.txt"};
char x [20];
int s ;
int n=0 ;
produit c;


window1=lookup_widget(objet,"window1");
input2=lookup_widget(objet,"entry10khlil");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(input2)));
s=verifier(x);
while((strcmp(x,"")!=0)&&(n==0))
{
if ( s==0)
{
output5 = lookup_widget(objet,"label37khlil") ;
gtk_label_set_text(GTK_LABEL(output5),"produit introuvable");
n=1;
}
else
{window4=lookup_widget(objet,"window4");
window4=create_window4();
gtk_widget_show(window4);
gtk_widget_destroy(window1);
strcpy(iden,x);
n=1;
}
}
if(n==0)
{
output6 = lookup_widget(objet,"label37khlil") ;
gtk_label_set_text(GTK_LABEL(output6),"il faut donner le nom");
}


}
//boutton suprimer produit
/*void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_ajouter,*input2,*treeview1,*output,*output1;
GtkWidget *input,*input1,*input3;

char fichierr[]={"utlisateur.txt"};
char x [20];
int s ;
int n=0 ;

window_ajouter=lookup_widget(objet,"window1");
input2=lookup_widget(objet,"entry11");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(input2)));
s=verifier(x);
while((strcmp(x,"")!=0)&&(n==0))
{
if (s==0)
{
output = lookup_widget(objet,"label36") ;
gtk_label_set_text(GTK_LABEL(output),"produit introuvable");
n=1;
}
else
{//partie affichage

input3=lookup_widget(objet,"window6");
input3=create_window6();
gtk_widget_show(input3);
input1=lookup_widget(objet,"window1");
gtk_widget_destroy(input1);
//gtk_widget_show(input2);//remarque
//treeview1=lookup_widget(input,"treeview1");
//affichage(fichierr,treeview1);
n=1;
strcpy(idd,x);
}
}
if(n==0)
{
output1 = lookup_widget(objet,"label36") ;
gtk_label_set_text(GTK_LABEL(output1),"il faut donner identifiant");
}
}*/


void
on_button3khlil_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *input3, *input1;
GtkWidget *label99khlil;
label99khlil = lookup_widget(button,"label99khlil");
if(strcmp(idd,"")==0){
gtk_widget_show(label99khlil);
} else {
input3=lookup_widget(button,"window6");
input3=create_window6();
gtk_widget_show(input3);
input1=lookup_widget(button,"window1");
gtk_widget_destroy(input1);
}
}

//boutton ajouter pour produit
void
on_button6khlil_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1, *input2,*input3,*input4,*output,*output1,*output2;
GtkWidget *window_ajouter,*combobox1khlil;
produit c;
int test ;
int n = 0 ;
char a[20];
char b[20];



combobox1khlil=lookup_widget(objet_graphique,"combobox1khlil");
window_ajouter=lookup_widget(objet_graphique,"window2");
input1=lookup_widget(objet_graphique,"spinbutton2khlil");
input2=lookup_widget(objet_graphique,"spinbutton3khlil");
input3=lookup_widget(objet_graphique,"entry4khlil");
input4=lookup_widget(objet_graphique,"entry5khlil");
if(strcmp("nourriture",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1khlil)))==0)
strcpy(c.type,"nourriture");
if(strcmp("nettoyage",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1khlil)))==0)
strcpy(c.type,"nettoyage");

sprintf(a,"%d",gtk_spin_button_get_value_as_int(GTK_ENTRY(input1)));
sprintf(b,"%d",gtk_spin_button_get_value_as_int(GTK_ENTRY(input2)));
strcpy(c.mois,a);
strcpy(c.annee,b);
strcpy(c.quantite,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input4)));

test = verifier(c.id);
while((strcmp(c.mois,"")!=0)&&(strcmp(c.annee,"")!=0)&&(strcmp(c.quantite,"")!=0)&&(strcmp(c.id,"")!=0)&&(n==0))
{
if(test==1)
{
output = lookup_widget(objet_graphique,"label7khlil") ;
gtk_label_set_text(GTK_LABEL(output),"identite deja existe");
n=1;
}
else
{
cli=c ;
GtkWidget *input0,*input00;
input0=lookup_widget(objet_graphique,"window5");
input0=create_window5();
gtk_widget_show(input0);
input00=lookup_widget(objet_graphique,"window2");
gtk_widget_destroy(input00);
n=1;

}
}
if(n==0)
{
output2=lookup_widget(objet_graphique,"label7khlil");
gtk_label_set_text(GTK_LABEL(output2),"remplir tout les informations!");
}
}


void
on_button5khlil_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input,*input1;
input=lookup_widget(objet,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet,"window2");
gtk_widget_destroy(input1);
}


void
on_radiobutton3khlil_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=1;}
}

//boutton afficher (modification produit)
void
on_button10khlil_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window3;
GtkWidget *output,*output1,*output2,*output3,*output4;
produit c ;
char fichier[]={"produit.txt"};
c=recherche(fichier,iden);
output = lookup_widget(objet,"label29khlil") ;
gtk_label_set_text(GTK_LABEL(output),c.mois);
output1 = lookup_widget(objet,"label30khlil") ;
gtk_label_set_text(GTK_LABEL(output1),c.annee);
output2 = lookup_widget(objet,"label33khlil") ;
gtk_label_set_text(GTK_LABEL(output2),c.id);
output3 = lookup_widget(objet,"label32khlil") ;
gtk_label_set_text(GTK_LABEL(output3),c.quantite);
output4 = lookup_widget(objet,"label31khlil") ;
gtk_label_set_text(GTK_LABEL(output4),c.type);
}

void
on_button12khlil_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*input3,*input4,*output1,*output2,*output3;
GtkWidget *window3;

produit x;
int m ;
int test ;
int n=0;
char fichierr[]={"produit.txt"};

window3=lookup_widget(objet,"window3");
if(y==1)
strcpy(x.type,"nourriture");
if(y==2)
strcpy(x.type,"nettoyage");


input1=lookup_widget(objet,"entry6khlil");
input2=lookup_widget(objet,"entry7khlil");
input3=lookup_widget(objet,"entry9khlil");
input4=lookup_widget(objet,"entry8khlil");


strcpy(x.mois,gtk_entry_get_text(GTK_ENTRY(input1)));//mois modifiée
strcpy(x.annee,gtk_entry_get_text(GTK_ENTRY(input2)));//annee modifiée
strcpy(x.id,gtk_entry_get_text(GTK_ENTRY(input3)));//id 
strcpy(x.quantite,gtk_entry_get_text(GTK_ENTRY(input4)));//quantite modifiéé



//partie validation de modification

test = verifier(x.id);

while((strcmp(x.mois,"")!=0)&&(strcmp(x.annee,"")!=0)&&(strcmp(x.quantite,"")!=0)&&(strcmp(x.id,"")!=0)&&(n==0))
{
if (test==1)
{

m =modifier_produit(fichierr,x);
output1 = lookup_widget(objet,"label35khlil") ;
gtk_label_set_text(GTK_LABEL(output1),"le produit modifié avec succes");
n=1;
}
else
{
output2 = lookup_widget(objet,"label35khlil") ;
gtk_label_set_text(GTK_LABEL(output2),"identifiant n'existe pas");
n=1;
}
}
if(n==0)
{
output3 = lookup_widget(objet,"label35khlil") ;
gtk_label_set_text(GTK_LABEL(output3),"il faut remplir tout les information");
}
}


void
on_radiobutton5khlil_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{z=1;}
}


void
on_radiobutton6khlil_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{z=2;}
}


void
on_button11khlil_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input,*input1,*input3,*input4,*input5;
if(z==1)
{
input=lookup_widget(objet,"window3");
input=create_window3();
gtk_widget_show(input);
input1=lookup_widget(objet,"window1");
gtk_widget_destroy(input1);
input3=lookup_widget(objet,"window4");
gtk_widget_destroy(input3);
}
if(z==2)
{
input4=lookup_widget(objet,"window1");
input4=create_window1();
gtk_widget_show(input4);
input5=lookup_widget(objet,"window4");
gtk_widget_destroy(input5);

}
}


void
on_checkbutton1khlil_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{w=1;}
else
{w=0;}
}


void
on_checkbutton2khlil_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{m=1;}
else
{m=0;}
}


void
on_button13khlil_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
int n = 0 ;
while((m!=w)&&(n==0))
{
if(w==1)
{
ajouter_produit(cli);
GtkWidget *input,*input1,*input2;
input=lookup_widget(objet_graphique,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet_graphique,"window2");
gtk_widget_destroy(input1);
input2=lookup_widget(objet_graphique,"window5");
gtk_widget_destroy(input2);
n=1;
}
if(m==1)
{
GtkWidget *input3,*input4;
input4=lookup_widget(objet_graphique,"window2");
input4=create_window2();
gtk_widget_show(input4);
input3=lookup_widget(objet_graphique,"window5");
gtk_widget_destroy(input3);
n=1;
}
}
if(n==0)
{
GtkWidget *output2,*input5;
input5=lookup_widget(objet_graphique,"window5");
output2 = lookup_widget(objet_graphique,"label44khlil") ;
gtk_label_set_text(GTK_LABEL(output2),"choisir oui ou non");
}
}


void
on_button14khlil_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *spinbutton1khlil;
GtkWidget *input,*input1,*input2,*input3,*input4,*treeview1khlil;
char fichierr[]={"produit.txt"};
int a,s ;
spinbutton1khlil=lookup_widget(objet_graphique,"spinbutton1khlil");
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1khlil));
if(a==1)
{
s=suprimer_produit(fichierr,idd);
input=lookup_widget(objet_graphique,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(objet_graphique,"window6");
gtk_widget_destroy(input1);
//gtk_widget_show(input2);//remarque
treeview1khlil=lookup_widget(input,"treeview1khlil");
affichage(fichierr,treeview1khlil);
}
if(a==0)
{
input3=lookup_widget(objet_graphique,"window6");
gtk_widget_destroy(input3);
input2=lookup_widget(objet_graphique,"window1");
input2=create_window1();
gtk_widget_show(input2);
treeview1khlil=lookup_widget(input3,"treeview1khlil");
affichage(fichierr,treeview1khlil);
}
}









void
on_button37khlil_clicked               (GtkButton       *button,
                                        gpointer         user_data)

{

 	/*GtkWidget *window1, *window7;
	GtkWidget *treeview2khlil;
	char fichier[]={".txt"};

	window7 = create_window7();
	window8 = lookup_widget(button,"window8");
	treeview2khlil = lookup_widget(window7,"treeview2khlil");
	gtk_widget_show(window7);
	gtk_widget_hide(window1);

	affichage(treeview2khlil);*/


}




void
on_button36khlil_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button8kkhlil_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *input,*input1;
input=lookup_widget(button,"window1");
input=create_window1();
gtk_widget_show(input);
input1=lookup_widget(button,"window3");
gtk_widget_destroy(input1);
}


void
on_radiobutton4khlil_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=2;}
}


void
on_button37_retourkhlil_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}

