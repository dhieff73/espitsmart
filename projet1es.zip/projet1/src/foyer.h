#include <gtk/gtk.h>
#include <stdio.h>
#include<string.h>




typedef struct 
{
char cin[30];
char nom[30];
char prenom[30];
char classe[30];
char sexe[30];
char block [30];
char chambre[30];

}etudiant ;


/////////////////////////////ajouter////////////////////////
void ajouter(etudiant e);
////////////////////////////afficher/////////////////////////
void afficher(GtkWidget *liste);
////////////////////////////supprimer///////////////////////
void supprimer(etudiant e);
///////////////////////modifier//////////////////////////
void modifier(etudiant e1);
///////////////////////rechercher/////////////////////
int recherche_etudiant(char*ci);
//////////////////////niveau///////////////////////////
int nombre_etu1();

int nombre_etu2();

int nombre_etu3();

int nombre_etu4();

int nombre_etu5();
