#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include "foyer.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"
int t[5]={0,0,0,0,0};
int x=0,y=0 ;
char ch1[20] , ch2[20] , ch[30] ;
etudiant e ;

GtkWidget *treeview1;


void
on_login_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{
etudiant e ;
GtkWidget *entry_name,*entry_pass;
GtkWidget *authen;
GtkWidget *gestion_des_etudiantss;
authen=lookup_widget(button,"login");
authen=lookup_widget(button,"authentification");
	gtk_widget_destroy(authen);

gestion_des_etudiantss = create_gestion_des_etudiants ();
  gtk_widget_show (gestion_des_etudiantss);

}


void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajout;
ajout = create_ajout();
  gtk_widget_show (ajout);

}


void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *affiche,*treeview1;
affiche=lookup_widget(button,"afficher");
treeview1=lookup_widget(button,"treeview1");
afficher(treeview1);

}



void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestion_des_etudiants;
gestion_des_etudiants=lookup_widget(button,"gestion_des_etudiants");
gtk_widget_destroy(gestion_des_etudiants);
gestion_des_etudiants=create_gestion_des_etudiants();
gtk_widget_show (gestion_des_etudiants);

}





void
on_valider_clicked                     (GtkButton       *button,
                                        gpointer         user_data)

{
etudiant e ;
GtkWidget *entry_cin,*entry_nom,*entry_prenom,*entry_classe,*entry_block,*entry_sexe,*entry_chambre;
GtkWidget *ajout , *ajoutt,*nbResultat1,*valide;
ajout=lookup_widget(button,"ajouter");
ajoutt=lookup_widget(button,"ajout");
entry_cin=lookup_widget(button,"entry_cin");
entry_nom=lookup_widget(button,"entry_nom");
entry_prenom=lookup_widget(button,"entry_prenom");
entry_classe=lookup_widget(button,"entry_classe");
entry_block=lookup_widget(button,"comboboxentry1");
entry_chambre=lookup_widget(button,"entry_chambre");

strcpy(e.cin,gtk_entry_get_text(GTK_ENTRY(entry_cin)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(entry_nom)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(entry_prenom)));
strcpy(e.classe,gtk_entry_get_text(GTK_ENTRY(entry_classe)));
strcpy(e.block,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entry_block)));

 if (x==1){
strcpy(e.sexe,"femelle");}
else if (x==0)
strcpy(e.sexe,"male");

strcpy(e.chambre,gtk_entry_get_text(GTK_SPIN_BUTTON(lookup_widget(button,"spinbutton1"))));

ajouter(e);
gtk_widget_destroy(ajoutt);


}

void
on_radiobutton2_gar__on_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
x=0;
}


void
on_radiobutton1_fille_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
x=1;
}


void
on_valider_supp_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
char cin [50];
GtkWidget *entry0;
GtkWidget *gestion_des_etudiants;
entry0=lookup_widget(button,"entry0");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(entry0)));
supprimer(e);


}




void
on_gar__on_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
y=2;
}


void
on_fille_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
y=1;
}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{t[0]=1;}
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{t[1]=1;}
}


void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{t[2]=1;}
}


void
on_checkbutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{t[4]=1;}
}


void
on_valider_chercher_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
etudiant e ;
GtkWidget *entry_cin;
entry_cin=lookup_widget(button,"entry1_cin");

GtkWidget *treeview1,*affiche;
affiche=lookup_widget(button,"afficher");
treeview1=lookup_widget(button,"treeview1");

}


void
on_valider_mod_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
etudiant e1 ;
GtkWidget *entry_cin,*entry_nom,*entry_prenom,*entry_classe,*entry_block,*entry_sexe,*entry_chambre;
GtkWidget *modification_infos,*gestion_des_etudiantss ,*authen ,*w1;

entry_cin=lookup_widget(button,"entry9_cin");
entry_nom=lookup_widget(button,"entry10_nom");
entry_prenom=lookup_widget(button,"entry11_prenom");
entry_classe=lookup_widget(button,"entry12_classe");
entry_block=lookup_widget(button,"comboboxentry2");
entry_chambre=lookup_widget(button,"entry_chambrem");
authen=lookup_widget(button,"modification_infos");
strcpy(e1.cin,gtk_entry_get_text(GTK_ENTRY(entry_cin) ) );
strcpy(e1.nom,gtk_entry_get_text(GTK_ENTRY(entry_nom) ) );
strcpy(e1.prenom,gtk_entry_get_text(GTK_ENTRY(entry_prenom) ) );
strcpy(e1.classe,gtk_entry_get_text(GTK_ENTRY(entry_classe) ) );

strcpy(e1.chambre,gtk_entry_get_text(GTK_SPIN_BUTTON(lookup_widget(button,"spinbutton2")))); 
 if (y==1){
strcpy(e1.sexe,"femelle");}
else
{strcpy(e1.sexe,"male");}

strcpy(e1.block,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entry_block)));

modifier(e1);


gtk_widget_destroy(authen);



}


void
on_ok_clicked                          (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *entry_cin;
entry_cin=lookup_widget(button,"ok");
 strcpy(e.cin,gtk_entry_get_text(GTK_ENTRY(entry_cin) ) );
GtkWidget *modification_infos;
modification_infos = create_modification_infos ();
  gtk_widget_show (modification_infos);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


        GtkTreeIter iter;
        gchar *cin;
        gchar *nom;
        gchar *prenom;
        gchar *classe;
        gchar  *sexe;
	gchar  *block;
	gint *chambre;
	etudiant e ;
      

	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path)){ 
	  gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&cin,1,&nom,2,&prenom,3,&classe,4,&sexe,5,&block,6,&chambre,-1);
	  strcpy(e.cin,cin);
	  strcpy(e.nom,nom);
	  strcpy(e.prenom,prenom);
	  strcpy(e.classe,classe);
	  strcpy(e.sexe,sexe);
  	  strcpy(e.block,block);
          strcpy(e.chambre,chambre);
		supprimer(e);

	afficher(treeview);


	}

}


void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{t[3]=1;}
}



void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modification_infos , *authen;
modification_infos=create_modification_infos();
gtk_widget_show(modification_infos);

}


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *treeview,*w1 ,*afficherr,*ajouter,*nbResultat1,*valide ;
GtkWidget *gestion_des_etudiants;
gestion_des_etudiants=lookup_widget(button,"gestion_des_etudiants");
gtk_widget_destroy(gestion_des_etudiants);

/*GtkWidget *w2;
	GtkWidget *treeview;

	w2 = lookup_widget(objet_graphique, "InterfaceAJout") ;
	gtk_widget_destroy (w2);

	w1 = lookup_widget(objet_graphique, "InterfaceAfficher") ;
	w1 = create_InterfaceAfficher();

	gtk_widget_show (w1);
	treeview = lookup_widget(w1, "treeview1") ;
	afficher_Equipement(treeview);*/
	
	w1=lookup_widget(button,"button1");
	gestion_des_etudiants=lookup_widget(button,"gestion_des_etudiants");
	gtk_widget_destroy(gestion_des_etudiants);
	afficherr = create_gestion_des_etudiants ();
	gtk_widget_show (afficherr);
	treeview = lookup_widget(afficherr, "treeview1") ;
	afficher(treeview);
valide=lookup_widget(button,"valider");
nbResultat1=lookup_widget(button,"label66");
  gtk_widget_show (nbResultat1);




}


void
on_quitterr_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestion_des_etudiantss , *authen , *w1;

w1=lookup_widget(button,"quitterr");
gestion_des_etudiantss=lookup_widget(button,"gestion_des_etudiants");
	gtk_widget_destroy(gestion_des_etudiantss);
authen=create_authentification();
gtk_widget_show(authen);
}


void
on_button_rechercher_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
etudiant e ;
/*GtkWidget *entry_rechercher;

entry_rechercher=lookup_widget(button,"entry_rechercher");
strcpy(e.cin,gtk_entry_get_text(GTK_ENTRY(entry_rechercher)));
if entry_rechercher==e.cin */

GtkWidget *entry;
GtkWidget *labelnom;
GtkWidget *nbResultat;
GtkWidget *message;
char nom[30];
int test ;
entry=lookup_widget(button,"button_rechercher");
labelnom=lookup_widget(button,"entry_rechercher");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(labelnom)));


test=recherche_etudiant(nom);
if (test == 1) {

nbResultat=lookup_widget(button,"label43");
  gtk_widget_show (nbResultat);
	}


	else if (test == 0){
message=lookup_widget(button,"label44");
  gtk_widget_show (message);}
	

		
}

/*if (exist_etudiant(nom)==0){
nbResultat=lookup_widget(button,"label44");
  gtk_widget_show (nbResultat);
}else{
message=lookup_widget(button,"label43");
  gtk_widget_show (message);*/




void
on_quitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestion_des_etudiantss , *authen , *w1;

w1=lookup_widget(button,"quitter");
gestion_des_etudiantss=lookup_widget(button,"ajout");
	gtk_widget_destroy(gestion_des_etudiantss);

}


void
on_quitterrr_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestion_des_etudiantss , *authen , *w1;

w1=lookup_widget(button,"quitterrr");
gestion_des_etudiantss=lookup_widget(button,"modification_infos");
	gtk_widget_destroy(gestion_des_etudiantss);

}









void
on_niveau_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w2 ,*gestion_des_etudiantss ,*niveauu;
w2=lookup_widget(button,"niveau");
	gestion_des_etudiantss=lookup_widget(button,"gestion_des_etudiants");
	gtk_widget_destroy(gestion_des_etudiantss);
	niveauu = create_niveauetudiant();
	gtk_widget_show (niveauu);
}


void
on_resultat_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{ GtkWidget *sortie1 ,*sortie2 ,*sortie3 ,*sortie4 ,*sortie5;



sortie1=lookup_widget(button,"sortie1");
sortie2=lookup_widget(button,"sortie2");
sortie3=lookup_widget(button,"sortie3");
sortie4=lookup_widget(button,"sortie4");
sortie5=lookup_widget(button,"sortie5");

int nbr1 , nbr2 , nbr3 , nbr4 ,nbr5 ;
char nbr1_e[20], nbr3_e[20] , nbr2_e[20] , nbr4_e[20]  , nbr5_e[20];
	



	nbr1=nombre_etu1();
	sprintf(nbr1_e,"%d", nbr1);

	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie1,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie1),nbr1_e);


	nbr2=nombre_etu2();
	sprintf(nbr2_e,"%d", nbr2);


	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie2,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie2),nbr2_e);

	nbr3=nombre_etu3();
	sprintf(nbr3_e,"%d", nbr3);


	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie3,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie3),nbr3_e);

	nbr4=nombre_etu4();
	sprintf(nbr4_e,"%d", nbr4);


	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie4,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie4),nbr4_e);


	nbr5=nombre_etu5();
	sprintf(nbr5_e,"%d", nbr5);

	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie5,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie5),nbr5_e);
}



void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestion_des_etudiantss , *authen , *w1;

w1=lookup_widget(button,"retour");
gestion_des_etudiantss=lookup_widget(button,"niveauetudiant");
gtk_widget_destroy(gestion_des_etudiantss);
authen=create_gestion_des_etudiants();
gtk_widget_show(authen);
}




