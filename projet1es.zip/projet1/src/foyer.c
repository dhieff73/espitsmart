
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "foyer.h"


enum
{
  ECIN,
  ENOM,
  EPRENOM,
  ECLASSE,
  ESEXE,
  EBLOCK,
  ECHAMBRE,
  COLUMNS
};

FILE *f;

////////////////////////////////////////////////////ajouter/////////////////////////////////////////////////////////////////
void ajouter(etudiant e)
{
FILE*f;
    f=fopen("etudiant.txt","a+");
  if (f!=NULL)
{
    fprintf(f,"%s %s %s %s %s %s %s\n",e.cin,e.nom,e.prenom,e.classe,e.sexe,e.block,e.chambre);
}
    fclose(f);
}




//////////////////////////////////////////////////supprimer////////////////////////////////////////////////////////////////
void supprimer (etudiant e){

char cin[30];
char nom[30];
char prenom[30];
char classe[30];
char sexe[30];
char block [30];
char chambre[30];
FILE *f,*g;
f=fopen("etudiant.txt","r+");
g=fopen("dump.txt","a+");
if(f==NULL || g==NULL)
{
return;
}
else{
while(fscanf(f,"%s %s %s %s %s %s %s\n",cin,nom,prenom,classe,sexe,block,chambre)!=EOF)
{
if (strcmp(e.cin,cin)!=0 || strcmp(e.nom,nom)!=0 || strcmp(e.prenom,prenom)!=0 || strcmp(e.classe,classe)!=0 || strcmp(e.block,block)!=0 || strcmp(e.sexe,sexe)!=0 || strcmp(e.chambre,chambre)!=0 )
fprintf(g,"%s %s %s %s %s %s %s\n",cin,nom,prenom,classe,sexe,block,chambre); 
}
fclose(f);
fclose(g);
remove("etudiant.txt");
rename("dump.txt","etudiant.txt");

}
}
/////////////////////////////////////////////////////////////afficher////////////////////////////////////////////////////////
void afficher (GtkWidget *liste)
{
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;



char cin[30];
char nom[30];
char prenom[30];
char classe[30];
char sexe[30];
char block [30];
char chambre[30]; 
	store = NULL;
  FILE *f;
	
  store=gtk_tree_view_get_model(liste);

  if (store==NULL)
  {
    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("cin",renderer,"text",ECIN,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("classe",renderer,"text",ECLASSE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("block",renderer,"text",EBLOCK,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

     renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("chambre",renderer,"text",ECHAMBRE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


   store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

    f = fopen("etudiant.txt","r");

    if (f==NULL)
    {
      return;
    }
    else{
      f = fopen("etudiant.txt","a+");
      while (fscanf(f,"%s %s %s %s %s %s %s  \n",cin,nom,prenom,classe,sexe,block,chambre)!=EOF){
        gtk_list_store_append(store, &iter);
	gtk_list_store_set(store,&iter,ECIN,cin,ENOM,nom,EPRENOM,prenom,ECLASSE,classe,ESEXE,sexe,EBLOCK,block,ECHAMBRE,chambre,-1);

      }
      fclose(f);
      gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		  g_object_unref(store);
    }}}

////////////////////////////////////////////////modifeir//////////////////////////////////////////////////////
void modifier(etudiant e1){
etudiant e;
FILE *f,*f1;
f=fopen("etudiant.txt","a+");
f1=fopen("user1.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s %s\n",e.cin,e.nom,e.prenom,e.classe,e.sexe,e.block,e.chambre)!=EOF){

if (strcmp(e1.cin,e.cin)==0){
fprintf(f1,"%s %s %s %s %s %s %s\n",e1.cin,e1.nom,e1.prenom,e1.classe,e1.sexe,e1.block,e1.chambre);
}
else{
fprintf(f1,"%s %s %s %s %s %s %s\n",e.cin,e.nom,e.prenom,e.classe,e.sexe,e.block,e.chambre);
}
}
fclose(f);
fclose(f1);
remove("etudiant.txt");
rename("user1.txt","etudiant.txt");
}



///////////////////////////////////////rechercher////////////////////////////////////////////////////////////

int recherche_etudiant(char*ci)
{
FILE* f;
etudiant e;
f=fopen("etudiant.txt","r+");
	if(f!=NULL)
	{
	while (fscanf(f,"%s %s %s %s %s %s %s\n",e.cin,e.nom,e.prenom,e.classe,e.sexe,e.block,e.chambre)!=EOF)
	
	
	if(strcmp(ci,(e.cin))==0)
		

		return(1);
return(0);
}
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////
int nombre_etu1(){
int nbr1=0;
etudiant e;
FILE * f ;
f=fopen("etudiant.txt","r");
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s\n",e.cin,e.nom,e.prenom,e.classe,e.sexe,e.block,e.chambre)!=EOF) 
{
	
if(strcmp(e.classe,"1")==0) { 
nbr1++;
}
}
fclose(f);
return (nbr1);

}

}
////////////////////////////////////////////////////////////////////////////////////////////////////////
int nombre_etu2(){
int nbr2=0;
etudiant e;
FILE * f ;
f=fopen("etudiant.txt","r");
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s\n",e.cin,e.nom,e.prenom,e.classe,e.sexe,e.block,e.chambre)!=EOF) 
{
	
if(strcmp(e.classe,"2")==0) { 
nbr2++;
}
}
fclose(f);
return (nbr2);

}

}
////////////////////////////////////////////////////////////////////////////////////////////////////////
int nombre_etu3(){
int nbr3=0;
etudiant e;
FILE * f ;
f=fopen("etudiant.txt","r");
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s\n",e.cin,e.nom,e.prenom,e.classe,e.sexe,e.block,e.chambre)!=EOF)
	
if(strcmp(e.classe,"3")==0) { 
nbr3++;
}
}
fclose(f);
return (nbr3);

}


////////////////////////////////////////////////////////////////////////////////////////////////////////
int nombre_etu4(){
int nbr4=0;
etudiant e;
FILE * f ;
f=fopen("etudiant.txt","r");
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s\n",e.cin,e.nom,e.prenom,e.classe,e.sexe,e.block,e.chambre)!=EOF) 
{
	
if(strcmp(e.classe,"4")==0) { 
nbr4++;
}
}
fclose(f);
return (nbr4);

}

}
////////////////////////////////////////////////////////////////////////////////////////////////////////
int nombre_etu5(){
int nbr5=0;
etudiant e;
FILE * f ;
f=fopen("etudiant.txt","r");
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s\n",e.cin,e.nom,e.prenom,e.classe,e.sexe,e.block,e.chambre)!=EOF) 
{
	
if(strcmp(e.classe,"5")==0) { 
nbr5++;
}
}
fclose(f);
return (nbr5);

}

}




	
